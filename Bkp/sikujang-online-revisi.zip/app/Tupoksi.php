<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tupoksi extends Model
{
    //
    protected $table = 'tupoksi';

    protected $fillable = [
        'id_jabatan', 'satuan', 'waktu', 'norma_waktu', 'sbk', 'uraian_kegiatan',
    ];

    public function position()
    {
        return $this->belongsTo(Position::class);
    }
}
