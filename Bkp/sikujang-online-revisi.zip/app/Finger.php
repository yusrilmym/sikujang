<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Finger extends Model
{
    //
}
