<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;

class Alamat extends Model
{
    //
    use HasApiTokens;
}
