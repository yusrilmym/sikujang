<?php $__env->startSection('content'); ?>
<div class="card card-success">
    <div class="card-header"><h4>Login</h4></div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <!-- TAMPILKAN NOTIF JIKA GAGAL LOGIN  -->
            <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text">
                    <i class="fas fa-user"></i>
                    </div>
                </div>
                <input aria-describedby="emailHelpBlock" id="nip" type="text" class="form-control<?php echo e($errors->has('nip') ? ' is-invalid' : ''); ?>" name="nip" placeholder="Input NIP atau Email" tabindex="1" value="<?php echo e(old('nip')); ?>" autofocus>
                </div>
                <div class="invalid-feedback">
                <?php echo e($errors->first('nip')); ?>

                </div>
            </div>

            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text">
                    <i class="fas fa-lock"></i>
                    </div>
                </div>
                <input aria-describedby="passwordHelpBlock" id="password" type="password" placeholder="Your account password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid': ''); ?>" name="password" tabindex="2">
                </div>
                <div class="invalid-feedback">
                <?php echo e($errors->first('password')); ?>

                </div>
            </div>

            <div class="form-group" >
                <div class="custom-control custom-checkbox">
                <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember"<?php echo e(old('remember') ? ' checked': ''); ?>>
                <label class="custom-control-label" for="remember" style="color: black">Remember Me</label>
                </div>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" tabindex="4">
                Login
                </button>
            </div>
        </form>
    </div>
</div>
<div class="mt-5 text-muted text-center">
  Don't have an account? <a href="<?php echo e(route('register')); ?>">Create One</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cleanlaravelui\resources\views/auth/login.blade.php ENDPATH**/ ?>