<?php $__env->startSection('content'); ?>
<div class="card card-primary">
  <div class="card-header"><h4>Register</h4></div>

  <div class="card-body">
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nickname">Nama Panggilan</label>
            <input id="nickname" type="text" class="form-control<?php echo e($errors->has('nickname') ? ' is-invalid' : ''); ?>" name="nickname" tabindex="1" placeholder="Nama Panggilan" value="<?php echo e(old('nickname')); ?>" autofocus>
            <div class="invalid-feedback">
                <?php echo e($errors->first('nickname')); ?>

            </div>
        </div>
        <div class="form-group">
            <label for="fullname">Nama Lengkap</label>
            <input id="fullname" type="text" class="form-control<?php echo e($errors->has('fullname') ? ' is-invalid' : ''); ?>" name="fullname" tabindex="1" placeholder="Nama lengkap beserta gelar" value="<?php echo e(old('fullname')); ?>" autofocus>
            <div class="invalid-feedback">
                <?php echo e($errors->first('fullname')); ?>

            </div>
        </div>
        <div class="form-group">
            <label for="nip">NIP</label>
            <input id="nip" type="number" class="form-control<?php echo e($errors->has('nip') ? ' is-invalid' : ''); ?>" name="nip" tabindex="1" placeholder="Nomor Induk Pegawai" value="<?php echo e(old('nip')); ?>" autofocus>
            <div class="invalid-feedback">
                <?php echo e($errors->first('nip')); ?>

            </div>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Email address" name="email" tabindex="1" value="<?php echo e(old('email')); ?>" autofocus>
            <div class="invalid-feedback">
            <?php echo e($errors->first('email')); ?>

            </div>
        </div>

        <div class="form-group">
            <label for="password" class="control-label">Password</label>
            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid': ''); ?>" placeholder="Set account password" name="password" tabindex="2">
            <div class="invalid-feedback">
            <?php echo e($errors->first('password')); ?>

            </div>
        </div>

        <div class="form-group">
            <label for="password_confirmation" class="control-label">Confirm Password</label>
            <input id="password_confirmation" type="password" placeholder="Confirm account password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid': ''); ?>" name="password_confirmation" tabindex="2">
            <div class="invalid-feedback">
            <?php echo e($errors->first('password_confirmation')); ?>

            </div>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
            Register
            </button>
        </div>
    </form>
  </div>
</div>
<div class="mt-5 text-muted text-center">
 Already have an account? <a href="<?php echo e(route('login')); ?>">Sign In</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cleanlaravelui\resources\views/auth/register.blade.php ENDPATH**/ ?>