<div class="footer-left inline">
  Copyright &copy; 2020 <div class="bullet"></div> RSUD Cibinong -- <a href="#">Handywepe</a>
</div>
<div class="footer-right">
  1.0.0
</div>
<?php /**PATH D:\laragon\www\sikujang\resources\views/partials/footer.blade.php ENDPATH**/ ?>