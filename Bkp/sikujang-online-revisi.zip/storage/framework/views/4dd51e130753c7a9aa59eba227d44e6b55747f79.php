<!DOCTYPE html>

<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Login &mdash; <?php echo e(env('APP_NAME')); ?></title>
  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
</head>

<body>
    <div id="app">
        <section class="section">
        <div class="d-flex flex-wrap align-items-stretch" style="margin-top: 0 !important">
            <div class="row" >
            <div class="col-lg-4 col-md-12 col-sm-12 col-12 order-lg-1 order-1 bg-white" style="height: auto">
                <div class="p-4 m-3">
                    <img src="<?php echo e(asset('/img/sikujang-logo.svg')); ?>" alt="logo" width="110" class="mb-2 mt-3">
                    <h4 class="text-dark font-weight-normal">Welcome to <span class="font-weight-bold">SiKujang</span></h4>
                    <p class="text-muted">Before you get started, you must login to continue.</p>
                    <?php if(session()->has('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('info')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('status')): ?>
                    <div class="alert alert-info">
                        <?php echo e(session()->get('status')); ?>

                    </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('login')); ?>" class="needs-validation" novalidate="">
                    <?php echo csrf_field(); ?>

                    <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="email">Email / NIP</label>
                        <input aria-describedby="emailHelpBlock" id="nip" type="text" class="form-control<?php echo e($errors->has('nip') ? ' is-invalid' : ''); ?>" name="nip" placeholder="Input NIP atau Email" tabindex="1" value="<?php echo e(old('nip')); ?>" autofocus>
                        <div class="invalid-feedback">
                        <?php echo e($errors->first('nip')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <div class="d-block">
                        <label for="password" class="control-label">Password</label>
                        </div>
                        <input aria-describedby="passwordHelpBlock" id="password" type="password" placeholder="Your account password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid': ''); ?>" name="password" tabindex="2">
                        <div class="invalid-feedback">
                        <?php echo e($errors->first('password')); ?>

                        </div>
                    </div>

                    <div class="form-group" >
                        <div class="custom-control custom-checkbox">
                        <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember"<?php echo e(old('remember') ? ' checked': ''); ?>>
                        <label class="custom-control-label" for="remember" style="color: black">Remember Me</label>
                        </div>
                    </div>

                    <div class="form-group text-right">
                        
                        <button type="submit" class="btn btn-primary btn-lg btn-icon icon-right" tabindex="4">
                        Login
                        </button>
                    </div>

                    
                    </form>

                    <div class="text-center mt-3 mb-3 text-small">
                    Copyright &copy; handywepe, <?php echo e(date('Y')); ?>

                    
                    </div>
                </div>
            </div>
                <div class="col-lg-8 col-md-12 col-sm-12 order-lg-2 order-2 background-walk-x position-relative overlay-gradient-bottom" data-background="<?php echo e(asset('/img/login-bg.jpg')); ?>" style="height: 100vh; background-size: cover">
                    <div class="absolute-bottom-left index-2">
                        <div class="text-light p-5 pb-2">
                        <greeting-comp></greeting-comp>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </section>
    </div>

    <script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
    <script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <script>
        // $(function() {
        //     $("html").getNiceScroll().resize();
        //     $("html").niceScroll();
        // });
    </script>
</body>
</html>
<style>
  html{
      overflow-y: auto;
      overflow-x: hidden
  }
  /* body, html{
      height: 100vh !important;
  } */
</style>
<?php /**PATH D:\laragon\www\sikujang\resources\views/auth/login.blade.php ENDPATH**/ ?>