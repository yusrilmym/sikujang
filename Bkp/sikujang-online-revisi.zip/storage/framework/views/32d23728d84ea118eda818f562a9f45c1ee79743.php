<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  
  <title><?php echo e(env('APP_NAME')); ?></title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="icon" type="image/png" href='<?php echo e(asset('img/favicon.png')); ?>'>
  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
  <?php echo $__env->yieldPushContent('stylesheet'); ?>
</head>

<body>
<div id="app">
    <?php echo $__env->yieldContent('app'); ?>
</div>


<?php if(auth()->guard()->check()): ?>
<script>
window.user = <?php echo json_encode(auth()->user(), 15, 512) ?>
</script>
<?php endif; ?>
<script>
    window.asset = '<?php echo e(asset('')); ?>';
</script>

<script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
<script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('javascript'); ?>

</body>
</html>
<?php /**PATH D:\laragon\www\sikujang-online\resources\views/layouts/skeleton.blade.php ENDPATH**/ ?>