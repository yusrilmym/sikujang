<aside id="sidebar-wrapper">
<div class="sidebar-brand shadow">
    <a > <img src='<?php echo e(asset('img/logo-rsud.png')); ?>' style="height: 35px !important" alt="RSUD Logo"> <?php echo e(env('APP_NAME')); ?></a>
    
</div>
<div class="sidebar-brand sidebar-brand-sm shadow">
    <img src='<?php echo e(asset('img/logo-rsud.png')); ?>' style="height: 40px !important" alt="RSUD Logo">
    
</div>

<ul class="sidebar-menu mt-2">
    <li class="menu-header">Menu</li>
    
    <li>
    <router-link to="/home" class="nav-link">
        <i class="fas fa-table"></i>
        <span>Dashboard</span>
    </router-link>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
    <li>
    <router-link to="/users" class="nav-link">
        <i class="fas fa-user-tie"></i>
        <span>Pegawai</span>
    </router-link>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <li>
    <router-link to="/users" class="nav-link">
        <i class="fas fa-hospital-user"></i>
        <span>Pegawai</span>
    </router-link>
    </li>
    <?php endif; ?>
</ul>

<ul class="sidebar-menu">
    <li class="menu-header">Setting</li>
    <li>
        <router-link to="/cek" class="nav-link">
        <i class="fas fa-cog"></i>
        <span>cek</span>
        </router-link>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
    <li>
        <router-link to="/passport" class="nav-link">
            <i class="fas fa-cog"></i>
            <span>Laravel Passport</span>
        </router-link>
    </li>
    <?php endif; ?>
</ul>
<ul class="sidebar-menu">
    <li class="nav-item dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fas fa-th"></i> <span>Master Data</span></a>
    <ul class="dropdown-menu">
        <li>
            <router-link to="/unit" class="nav-link ddmenu">
                <i class="fas fa-cog"></i>
                <span>Unit Kerja</span>
            </router-link>
        </li>
        <li>
            <router-link to="/position" class="nav-link ddmenu">
                <i class="fas fa-cog"></i>
                <span>Jabatan</span>
            </router-link>
        </li>
    </ul>
    </li>
</ul>
<ul class="sidebar-menu">
    <li class="nav-item dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fas fa-th"></i> <span>Bootstrap</span></a>
    <ul class="dropdown-menu">
        <li><a class="nav-link" href="bootstrap-alert.html">Alert</a></li>
        <li><a class="nav-link" href="bootstrap-badge.html">Badge</a></li>
        <li><a class="nav-link" href="bootstrap-breadcrumb.html">Breadcrumb</a></li>
        <li><a class="nav-link" href="bootstrap-buttons.html">Buttons</a></li>
        <li><a class="nav-link" href="bootstrap-card.html">Card</a></li>
        <li><a class="nav-link" href="bootstrap-carousel.html">Carousel</a></li>
        <li><a class="nav-link" href="bootstrap-collapse.html">Collapse</a></li>
        <li><a class="nav-link" href="bootstrap-dropdown.html">Dropdown</a></li>
        <li><a class="nav-link" href="bootstrap-form.html">Form</a></li>
        <li><a class="nav-link" href="bootstrap-list-group.html">List Group</a></li>
        <li><a class="nav-link" href="bootstrap-media-object.html">Media Object</a></li>
        <li><a class="nav-link" href="bootstrap-modal.html">Modal</a></li>
        <li><a class="nav-link" href="bootstrap-nav.html">Nav</a></li>
        <li><a class="nav-link" href="bootstrap-navbar.html">Navbar</a></li>
        <li><a class="nav-link" href="bootstrap-pagination.html">Pagination</a></li>
        <li><a class="nav-link" href="bootstrap-popover.html">Popover</a></li>
        <li><a class="nav-link" href="bootstrap-progress.html">Progress</a></li>
        <li><a class="nav-link" href="bootstrap-table.html">Table</a></li>
        <li><a class="nav-link" href="bootstrap-tooltip.html">Tooltip</a></li>
        <li><a class="nav-link" href="bootstrap-typography.html">Typography</a></li>
    </ul>
    </li>
</ul>
</aside>
<?php /**PATH D:\laragon\www\cleanlaravelui\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>