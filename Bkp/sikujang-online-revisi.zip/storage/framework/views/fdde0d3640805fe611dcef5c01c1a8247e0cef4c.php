<aside id="sidebar-wrapper">
<div class="sidebar-brand shadow">
    <a > <img src='<?php echo e(asset('img/logo-rsud.png')); ?>' style="height: 35px !important" alt="RSUD Logo"> <?php echo e(env('APP_NAME')); ?></a>
    
</div>
<div class="sidebar-brand sidebar-brand-sm shadow">
    <img src='<?php echo e(asset('img/logo-rsud.png')); ?>' style="height: 40px !important" alt="RSUD Logo">
    
</div>

<ul class="sidebar-menu mt-2">
    <li class="menu-header">Menu</li>
    
    <li>
    <router-link to="/home" class="nav-link">
        <i class="fas fa-tachometer-alt"></i>
        <span>Dashboard</span>
    </router-link>
    </li>
    
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdminAndPlus')): ?>
    <li>
        <router-link to="/users" class="nav-link">
            <i class="fas fa-user-tie"></i>
            <span>Pegawai</span>
        </router-link>
    </li>
    <?php endif; ?>
    
    <li>
    <router-link to="/jadwalshift" class="nav-link">
        <i class="far fa-calendar-check"></i>
        <span>Jadwal Shift</span>
    </router-link>
    </li>
</ul>

<ul class="sidebar-menu">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSys')): ?>
    <li class="menu-header">Setting</li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
    <li class="menu-header">Setting</li>
    <?php endif; ?>
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSys')): ?>
    <li>
        <router-link to="/passport" class="nav-link">
            <i class="fas fa-cog"></i>
            <span>Laravel Passport</span>
        </router-link>
    </li>
    <?php endif; ?>
</ul>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSys')): ?>
<ul class="sidebar-menu">
    <li class="nav-item dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fas fa-server"></i> <span>Master Data</span></a>
    <ul class="dropdown-menu">
        <li>
            <router-link to="/unit" class="nav-link ddmenu">
                <i class="fas fa-building"></i>
                <span>Unit Kerja</span>
            </router-link>
        </li>
        <li>
            <router-link to="/position" class="nav-link ddmenu">
                <i class="fas fa-briefcase"></i>
                <span>Jabatan</span>
            </router-link>
        </li>
        <li>
            <router-link to="/shift" class="nav-link ddmenu">
                <i class="fas fa-clock"></i>
                <span>Waktu Shift</span>
            </router-link>
        </li>
    </ul>
    </li>
</ul>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
<ul class="sidebar-menu">
    <li class="nav-item dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fas fa-server"></i> <span>Master Data</span></a>
    <ul class="dropdown-menu">
        <li>
            <router-link to="/unit" class="nav-link ddmenu">
                <i class="fas fa-building"></i>
                <span>Unit Kerja</span>
            </router-link>
        </li>
        <li>
            <router-link to="/position" class="nav-link ddmenu">
                <i class="fas fa-briefcase"></i>
                <span>Jabatan</span>
            </router-link>
        </li>
        <li>
            <router-link to="/shift" class="nav-link ddmenu">
                <i class="fas fa-clock"></i>
                <span>Waktu Shift</span>
            </router-link>
        </li>
    </ul>
    </li>
</ul>
<?php endif; ?>

</aside>
<?php /**PATH D:\laragon\www\sikujang\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>