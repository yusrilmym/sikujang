<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Login &mdash; <?php echo e(env('APP_NAME')); ?></title>
  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
</head>

<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              <img src="<?php echo e(asset('/img/logo-rsud.png')); ?>" alt="logo" width="100">
              <div>SiKujang RSUD</div>
            </div>
            <?php if(session()->has('info')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('info')); ?>

            </div>
            <?php endif; ?>
            <?php if(session()->has('status')): ?>
            <div class="alert alert-info">
                <?php echo e(session()->get('status')); ?>

            </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
            <div class="simple-footer">
              Copyright &copy; <?php echo e(env('APP_NAME')); ?> <?php echo e(date('Y')); ?>

            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
  <script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
  <script>
    $(function() {
        $("body").getNiceScroll().resize();
        $("body").niceScroll();
    });
  </script>
</body>
</html>
<style>
    html{
        overflow: visible;
    }
</style>
<?php /**PATH D:\laragon\www\sikujang\resources\views/layouts/auth.blade.php ENDPATH**/ ?>