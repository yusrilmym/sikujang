<?php $__env->startSection('app'); ?>

<div class="main-wrapper">
    <div class="navbar-bg"></div>
    <nav class="navbar navbar-expand-lg main-navbar">
      <?php echo $__env->make('partials.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
    <div class="main-sidebar shadow-lg">
      <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    
    <!-- Main Content -->
    <div class="main-content" style="height: auto !important">

            
            <router-view></router-view>
            <vue-progress-bar></vue-progress-bar>

    </div>
    <footer class="main-footer">
      <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.skeleton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cleanlaravelui\resources\views/layouts/app.blade.php ENDPATH**/ ?>