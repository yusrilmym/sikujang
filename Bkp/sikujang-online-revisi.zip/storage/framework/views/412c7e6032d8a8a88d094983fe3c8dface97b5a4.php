<search-comp/>
<?php /**PATH D:\laragon\www\cleanlaravelui\resources\views/partials/searchhistory.blade.php ENDPATH**/ ?>