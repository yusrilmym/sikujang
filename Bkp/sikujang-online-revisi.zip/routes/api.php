<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::apiResources(['user' => 'API\UserController']);
Route::apiResources(['unit' => 'API\UnitController']);
Route::apiResources(['position' => 'API\PositionController']);
Route::apiResources(['alamat' => 'API\AlamatController']);
Route::apiResources(['shift' => 'API\ShiftController']);
Route::apiResources(['schedule' => 'API\ScheduleController']);
Route::apiResources(['activity' => 'API\ActivitiesController']);
Route::apiResources(['rkk' => 'API\RkkController']);
Route::apiResources(['tupoksi-jfu' => 'API\TupoksiJfuController']);
Route::apiResources(['tupoksi-jft' => 'API\TupoksiJftController']);

Route::post('filterunit', 'API\ScheduleController@filterUnit');
Route::post('jft-jabatan', 'API\TupoksiJftController@filterJabatan');
Route::get('jftbyid/{id}', 'API\TupoksiJftController@jftById');
Route::post('jfu-jabatan', 'API\TupoksiJfuController@filterJabatan');
Route::get('jfubyid/{id}', 'API\TupoksiJfuController@jfuById');


Route::post('activity/bydate', 'API\ActivitiesController@byDate');
Route::post('activity/byuserdate', 'API\ActivitiesController@byUserDate');
Route::put('apprdecl/{id}', 'API\ActivitiesController@ApproveDecline');
Route::get('userlogin', 'API\UserController@userLogin');
Route::get('profile', 'API\UserController@profile');
Route::put('profile', 'API\UserController@updateProfile');
Route::get('userbyunit', 'API\UserController@userByUnit');
Route::get('userbybagian', 'API\UserController@userByBagian');
Route::post('alluserbyunit', 'API\UserController@allUserByUnit');
Route::get('findUser', 'API\UserController@search');
Route::get('jabatan-jfu', 'API\PositionController@showjfu');
Route::get('jabatan-jft', 'API\PositionController@showjft');

// Route::get('show/{user}', 'API\UserController@show');
// Route::get('detail/{user}', 'API\UserController@show');
Route::put('photo/{id}', 'API\UserController@updatePhoto');
Route::put('user/changepwd/{id}', 'API\UserController@changePwd');
Route::get('unitbybagian', 'API\UnitController@unitByBagian');
Route::post('activitybidper', 'API\ActivitiesController@createBidPer');
Route::put('activitybidperedit', 'API\ActivitiesController@updateBidPer');
// Route::get('profile/{user}', 'API\UserController@show');
// Route::put('profileid', 'API\UserController@updateProfileId');

// Route::get('checkinout', 'API\UserController@checkinout');

//route jabatan
Route::apiResources(['position' => 'API\PositionController']);
Route::apiResources(['unit' => 'API\UnitController']);

