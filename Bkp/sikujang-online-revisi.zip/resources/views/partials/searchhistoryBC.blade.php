<div class="search-result">
  <div class="search-header">
    Histories
  </div>
  <div class="search-item">
    <a href="#">How to hack NASA using CSS</a>
    <a href="#" class="search-close"><i class="fas fa-times"></i></a>
  </div>
  <div class="search-item">
    <a href="#">Kodinger.com</a>
    <a href="#" class="search-close"><i class="fas fa-times"></i></a>
  </div>
  <div class="search-item">
    <a href="#">#Stisla</a>
    <a href="#" class="search-close"><i class="fas fa-times"></i></a>
  </div>
  <div class="search-header">
    Result
  </div>
  <div class="search-item">
    <a href="#">
      <img class="mr-3 rounded" width="30" src="../assets/img/products/product-3-50.png" alt="product">
      oPhone S9 Limited Edition
    </a>
  </div>
  <div class="search-item">
    <a href="#">
      <img class="mr-3 rounded" width="30" src="../assets/img/products/product-2-50.png" alt="product">
      Drone X2 New Gen-7
    </a>
  </div>
  <div class="search-item">
    <a href="#">
      <img class="mr-3 rounded" width="30" src="../assets/img/products/product-1-50.png" alt="product">
      Headphone Blitz
    </a>
  </div>
  <div class="search-header">
    Projects
  </div>
  <div class="search-item">
    <a href="#">
      <div class="search-icon bg-danger text-white mr-3">
        <i class="fas fa-code"></i>
      </div>
      Stisla Admin Template
    </a>
  </div>
  <div class="search-item">
    <a href="#">
      <div class="search-icon bg-primary text-white mr-3">
        <i class="fas fa-laptop"></i>
      </div>
      Create a new Homepage Design
    </a>
  </div>
</div>
