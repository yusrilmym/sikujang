export default class Asset{

    constructor(asset){
        this.asset = asset;
    }

}
